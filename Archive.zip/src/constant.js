export const itemPerPage = 10;
export const paginationCount = 5;
